ini.exe (Trojan)

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

1. What even is ini.exe?
ini.exe is a trojan horse made in C++. This is made only for educational purposes. DO NOT TRY TO PRANK ANYONE WITH IT!
2. Is the malware safe? Yes. But if it makes you think you are fucked. Do not panic! Just click no if you are not brave.




idk what else to add..













-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


fun fact: i made this malware when i had the stomach flu... :< 
